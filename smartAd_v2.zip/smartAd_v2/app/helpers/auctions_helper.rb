module AuctionsHelper
end
