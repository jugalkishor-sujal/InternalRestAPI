module BidsHelper
end
