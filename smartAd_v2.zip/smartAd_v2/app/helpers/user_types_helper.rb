module UserTypesHelper
end
