module PeriodsHelper
end
