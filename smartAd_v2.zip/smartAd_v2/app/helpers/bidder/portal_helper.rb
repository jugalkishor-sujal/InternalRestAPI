module Bidder::PortalHelper
end
