module Bidder::BidsHelper
end
