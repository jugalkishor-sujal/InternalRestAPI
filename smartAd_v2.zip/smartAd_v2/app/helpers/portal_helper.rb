module PortalHelper
end
