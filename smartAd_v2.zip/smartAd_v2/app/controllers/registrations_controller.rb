class RegistrationsController < ::Devise::RegistrationsController
  layout 'sign_in'
  
end