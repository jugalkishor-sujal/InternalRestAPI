class Bid < ActiveRecord::Base
  belongs_to :auction

end
