require 'test_helper'

class PortalControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
