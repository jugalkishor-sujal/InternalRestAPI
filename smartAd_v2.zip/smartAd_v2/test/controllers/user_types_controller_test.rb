require 'test_helper'

class UserTypesControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
