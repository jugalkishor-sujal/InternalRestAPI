require 'test_helper'

class PeriodsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
