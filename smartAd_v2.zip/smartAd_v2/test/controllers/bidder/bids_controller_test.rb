require 'test_helper'

class Bidder::BidsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
