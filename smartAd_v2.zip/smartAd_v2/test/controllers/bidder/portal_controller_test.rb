require 'test_helper'

class Bidder::PortalControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
