require 'test_helper'

class TimeSharesControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
