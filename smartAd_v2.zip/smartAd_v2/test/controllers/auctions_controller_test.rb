require 'test_helper'

class AuctionsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
