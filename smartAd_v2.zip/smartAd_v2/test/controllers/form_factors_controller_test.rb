require 'test_helper'

class FormFactorsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
