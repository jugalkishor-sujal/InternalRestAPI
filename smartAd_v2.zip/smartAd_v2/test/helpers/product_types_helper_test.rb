require 'test_helper'

class ProductTypesHelperTest < ActionView::TestCase
end
