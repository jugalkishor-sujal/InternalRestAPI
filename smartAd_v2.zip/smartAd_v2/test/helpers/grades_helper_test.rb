require 'test_helper'

class GradesHelperTest < ActionView::TestCase
end
