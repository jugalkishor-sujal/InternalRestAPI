require 'test_helper'

class Bidder::BidsHelperTest < ActionView::TestCase
end
