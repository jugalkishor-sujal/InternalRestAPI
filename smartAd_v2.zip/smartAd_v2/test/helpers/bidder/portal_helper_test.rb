require 'test_helper'

class Bidder::PortalHelperTest < ActionView::TestCase
end
