require 'test_helper'

class BidsHelperTest < ActionView::TestCase
end
