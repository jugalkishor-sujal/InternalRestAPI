require 'test_helper'

class PortalHelperTest < ActionView::TestCase
end
