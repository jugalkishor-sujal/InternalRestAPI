require 'test_helper'

class TimeSharesHelperTest < ActionView::TestCase
end
