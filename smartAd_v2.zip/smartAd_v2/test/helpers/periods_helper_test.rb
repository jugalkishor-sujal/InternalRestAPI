require 'test_helper'

class PeriodsHelperTest < ActionView::TestCase
end
