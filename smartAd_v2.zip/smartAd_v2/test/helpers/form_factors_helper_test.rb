require 'test_helper'

class FormFactorsHelperTest < ActionView::TestCase
end
