require 'test_helper'

class FormatsHelperTest < ActionView::TestCase
end
