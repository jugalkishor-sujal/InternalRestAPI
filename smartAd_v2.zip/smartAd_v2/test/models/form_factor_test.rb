require 'test_helper'

class FormFactorTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
