require 'test_helper'

class TimeShareTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
